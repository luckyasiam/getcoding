<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
	/**
	 * The attributes that are mass assignable
	 * @var arry
	 */
    protected $fillable = [
    	'first_name', 'last_name', 'email', 'password', 'active',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     * @var [type]
     */
    protected $hidden = [
    	'password', 'remember_token',
    ];

    public function article()
    {
        return $this->hasMany('App\article');
    }
}
