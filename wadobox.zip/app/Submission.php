<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Submission extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [

	 	'user_id',
        'status',
        'active'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
