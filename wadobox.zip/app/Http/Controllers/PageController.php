<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;
use App\Http\Requests;
use App\Http\Controllers\ArticleController;
use Illuminate\HttpResponse;

class PageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active_menu = 'Home';
        $label = $this->getLabel();
        $menuList = $this->getMenuList();
        $about = $this->getAboutUsContent();
        $contents = $this->getContent();
    	return view('index', compact(['menuList', 'active_menu', 'contents', 'about', 'label']));
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }

    /**
     * [getMenuList description]
     * @return [type] [description]
     */
    private function getMenuList()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getContent description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getContent($content='', $id='')
    {            
        $article = new ArticleController;
        if ($id) {
            return $article->getPaginatedContent($content='', $id);
        } else {
            return $article->getPaginatedContent(strtolower($content));
        }
    }

    /**
     * [getLabel description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getLabel()
    {
        $article = new ArticleController;
        return $article->getLabel();
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.reg-form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $tag='', $id='')
    {
        $active_menu = 'Home';
        $label = $this->getLabel();
        $menuList = $this->getMenuList();
        $about = $this->getAboutUsContent();
        if ($id) {            
        $contents = $this->getContent(0, $id);
        } else {
            $contents = $this->getContent($tag);
        }
        if (count($contents)) {
            return view('index', compact(['menuList', 'active_menu', 'contents', 'about', 'label']));
        } else {
            $url = $request->path();
            return view('errors.page_not_found', compact(['url', 'menuList', 'active_menu', 'contents', 'about', 'label']));
        }
                        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return redirect('/');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return redirect('/');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return redirect('/');
    }


    /////////////////////////////////////////////////////////////////////////////////////////
    /// NOT to be Use Functions

    public function Job()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Jobs';
        return view('pages.jobs', compact(['menuList', 'active_menu']));
    }

    public function scholarship()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Scholarships';
        return view('pages.scholarships', compact(['menuList', 'active_menu']));
    }

    public function bursary()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.bursary', compact(['menuList', 'active_menu']));
    }

    public function news()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.news', compact(['menuList', 'active_menu']));
    }

    public function blog()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.blog', compact(['menuList', 'active_menu']));
    }

    public function forum()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.forum', compact(['menuList', 'active_menu']));
    }

    public function education()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.education', compact(['menuList', 'active_menu']));
    }

    public function science()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.science', compact(['menuList', 'active_menu']));
    }

    public function technology()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'Home';
        return view('pages.technology', compact(['menuList', 'active_menu']));
    }

    public function about()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $active_menu = 'About Us';
        return view('pages.about-us', compact(['menuList', 'active_menu']));
    }
}
