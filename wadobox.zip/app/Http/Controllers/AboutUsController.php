<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;
use App\Http\Requests;
use App\Http\Requests\ArticleRequest;
use App\Http\Requests\ArticleImageRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ArticleImageController;
use App\Http\Controllers\LabelController;
use App\Http\Controllers\PaginationController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;

use Auth;
use DB;


class AboutUsController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin', ['except' => [
            'index',
            'show',
        ]]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active_menu = 'About-us';
        $label = $this->getLabel();
        $menuList = $this->getMenuList();
        $about = $this->getAboutUsContent();
        $contents = $this->getAboutUsContent();
        return view('pages.about.index', compact(['menuList', 'active_menu', 'contents', 'label']));      
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }


    /**
     * [getMenuList description]
     * @return [type] [description]
     */
    private function getMenuList()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getLabel description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getLabel()
    {
        $article = new ArticleController;
        return $article->getLabel();
    }

    /**
     * [getContent description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getContent($content)
    {
        $article = new ArticleController;
        return $article->getPaginatedContent(strtolower($content));
    }
 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $sn = 0;
      $child = 'crea';
      $active = 'abou';
      $articles_count = $this->getContentCount();
      return view('admin.about_us.create', compact(['articles', 'sn', 'active', 'child', 'articles_count']));
    }

     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ArticleRequest $request)
    { 
        if ($this->getPermission()) {
            //check if incomming request has file.            
            if ($request->file('file')) {
                ///store new file to starage.
                $image = time().$request->file('file')->hashName();
                $moved = Storage::disk('local')->put($image, file_get_contents($request->file('file')->getRealPath()));
                // store article image name and input to database
                if ($moved) {
                    $article = new Article();
                    $article->title = $request->input('title');
                    $article->tag = $request->input('tag');
                    $article->body = $request->input('body');
                    $article->image = $image;
                    $article->image_name = $request->file('file')->getClientOriginalName();
                    $article->mime = $request->file('file')->getClientMimeType();
                    $article->active = $request->input('active') ? 1 : 0;
                    $article->status = 0;
                    $article->reads = 0;
                    $article->published_at = $request->input('active') ? Carbon::now() : '0';
                    $saved = Auth::user()->article()->save($article);
                    if ($saved) {
                        return redirect('/about-us/1')->with('message', 'Successfully uploaded');
                    } else {
                        return redirect()->back()->with('message', 'Error sending file to server');
                    }            
                } else {
                    return redirect()->back()->with('message', 'Error uploading file to storage disk');
                }
            }else{
              return redirect()->back()->withInput()->with('message', 'Bad image or File not found');
            } 
        } else {
            return redirect('admin/articles/')->with('message', 'You dont have the privileges to post as Admin');
        }
    }


    // $id = DB::table('users')->insertGetId($article);

    /**
     * Get the specified resource.
     *
     * @param  \Illuminate\Http\ArticleImageRequest
     * @return \Illuminate\Http\Response
     */
    public function save_article_image(ArticleImageRequest $request, $article_id = '')
    {
        $input = 'article_image';
        $articleImage= new ArticleImageController;
        return $articleImage->store($request, $input, $article_id);        
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if ($id === '1') {
            $contents = $this->getAboutUsContent();
            if (Auth::user()->admin && Auth::user()->active) {
                $sn = 0;
                $message = '';
                $child = 'edit';
                $active = 'abou';
                $article = $contents;
                $articles_count = $this->getContentCount();
               return view('admin.about_us.show', compact(['article', 'sn', 'active', 'child', 'articles_count', 'message']));
            } else {                
                $active_menu = 'About-us';
                $label = $this->getLabel();
                $menuList = $this->getMenuList();
                $about = $this->getAboutUsContent();
                return view('pages.about.show', compact(['menuList', 'active_menu', 'contents', 'label', 'about']));
            }
        } else {
            return redirect()->back()->with('message', 'You dont have this permission!');
        }
        
        
    }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function showContent($id)
  {
    return Article::find($id);            
  }

  
  /**
   * Get permission to edit
   * @return [type] [description]
   */
  private function getPermission()
  {
      return true;
  }

  /**
   * Get required article from DB.
   * @param  [type] $id [description]
   * @return [type]     [description]
   */
  private function getArticle($id)
  {
      $article= Article::find($id);
      return $article;
  }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($this->getPermission()) {            
            $sn = 0;
            $message = '';
            $child = 'edit';
            $active = 'abou';
            $articles_count = $this->getContentCount();
            $article= $this->getAboutUsContent();///This is possible since we have only one object in the table.
            if ($article && count($article)) {
                return view('admin.about_us.show', compact(['article', 'sn', 'active', 'child', 'articles_count', 'message']));
            } else {
                $message ='About us page is blank. Upload new!.';
                return view('admin.about_us.edit', compact(['article', 'sn', 'active', 'child', 'articles_count', 'message']));
            } 
        } else {
            return redirect()->back()->with('message', 'You dont have admin permission!');
        } 
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ArticleRequest $request, $id)
    {
        if ($this->getPermission()) {
            $article = $this->getArticle($id);
            if (($article) && (count($article))) {  
                //check if incomming request has file.
                if ($request->file('file')) {
                    // delete old file if exist from storage.
                    if (Storage::disk('local')->exists($article->image)) {
                        Storage::delete($article->image);
                    }
                    ///store new file to starage.
                    $image = time().$request->file('file')->hashName();
                    $moved = Storage::disk('local')->put($image, file_get_contents($request->file('file')->getRealPath()));
                    // update articlebase record file.
                    if ($moved) {
                        $article = new Article();
                        $updated = Auth::user()
                            ->article()
                            ->where('id', $id)
                            ->update([
                                'title'         => $request->input('title'),
                                'tag'           => $request->input('tag'),
                                'body'          => $request->input('body'),
                                'image'         => $image,
                                'image_name'    => $request->file('file')->getClientOriginalName(),
                                'mime'          => $request->file('file')->getClientMimeType(),
                                'active'        => $request->input('active') ? 1 : 0,
                                'status'        => 0,
                                'reads'         => 0,
                                'published_at'  => $request->input('active') ? Carbon::now() : '0'
                        ]);
                        if ($updated) {
                        return redirect('/about-us/1')->with('message', 'Successfully updated');
                        } else {
                            return redirect()->back()->with('message', 'Error sending file to server');
                        }            
                    } else {
                        return redirect()->back()->with('message', 'Error uploading file to storage disk');
                    }
                }else{
                  return redirect()->back()->withInput()->with('message', 'The picture/image is not a valid one');
                } 
            } else {
                return redirect('admin/articles/')->with('message', 'Error retrieving file from database');
            }
        } else {
            return redirect('admin/articles/')->with('message', 'You dont have the privileges to post as Admin');
        }         
    }




  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    Article::where('id', $id)->delete();
    return redirect('admin/articles');
  }



  ///////////////////////////////////////////////////////////////////////////////////////////////
    // UnUsed functions   
  public function getPage($page)
  {
    $idCount = $this->getIdCount($page);
    if ($idCount) {
      return Article::latest('published_at')->published()->where('id', '<', $idCount)->paginate(10);
    } else {
      return false;
    }   
  }

  public function getMenuPage($menu)
  {
    $idCount = $this->getMenuIdCount($menu);
    if ($idCount) {
      return Article::latest('published_at')->published()->where(['tag' => $menu, ])->paginate(10);
    } else {
      return false;
    }   
  }
      
  public function getPagination()
  {
    $pagination = new PaginationController;      
    return $pagination->getPagination($this->getContent());
  }

  public function getMenuPagination($menu)
  {
    $pagination = new PaginationController;
    return $pagination->getMenuPagination($this->getMenuContent($menu));
  }
    
  public function getMenuContent($menu)
  {
    return Article::latest('published_at')->published()->where('tag', $menu)->get();
  }

  public function getContentCount($menu = '')
  {
  if ($menu !== '') {
     return count(Article::where($menu, $menu)->get());
  } else {
     return count(Article::get());
  }    
  }

  public function getIdCount($page = '')
  {    
    if (($this->getContentCount() - ($page - 9)) > 0) {
      return $this->getContentCount() - ($page - 9);
    } else {
      return false;
    }
  }

  public function getMenuIdCount($page = '', $menu = '')
  {    
    if (($this->getContentCount($menu) - ($page - 9)) > 0) {
      return $this->getContentCount() - ($page - 9);
    } else {
      return false;
    }
  }

    /**
     * [getUserImage description]
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    // public function getArticleImage($filename)
    // {
    //     $article= $this->getArticle($_GET['id']);
    //     if (($article->image === $filename) && ($article&& count($article))) {
    //         $file = Storage::disk('local')->get($article->image); 
    //         return response($file, 200)
    //               ->header('Content-Type', $article->mime);
    //     } else {
    //         return redirect('/')->with('message', 'STOP! what are you trying to do?');
    //     }         
    // }
}
