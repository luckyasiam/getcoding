<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\HttpResponse;

use App\User;
use App\Information;
use App\Result;
use App\Undergraduate;
use App\UserPassport;
use App\UserDocument;
use App\DataControl;
use App\Bank;
use Illuminate\Support\Facades\Schema;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\UserDocumentController;

use App\Http\Requests;
use App\Http\Requests\DataControlRequest;
use DB;



class DatabaseController extends Controller
{
     /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin', ['except' => 'update']);
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sn = 0;
        $active = 'data';
        $child = 'endi';
        $articles_count = $this->getContentCount();
        $tables = $this->getAllTables();
        return view('admin.admins.database', compact(['tables', 'resource', 'sn', 'active', 'child', 'articles_count']));
    }

    public function getAllTables()
    {
        return DataControl::get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sn = 0;
        $active = 'data';
        $child = 'addt';
        $articles_count = $this->getContentCount();
        $tables = $this->getAllTables();
        return view('admin.admins.add_to_db', compact(['sn', 'active', 'child', 'articles_count']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DataControlRequest $request)
    {
        if (Schema::hasTable(trim($request->name))) {            
            $data = new DataControl($request->all());
            // dd('Sorry!: You are not allowed to perform this operation');
            $data->save();
        } else {
            return redirect()->back()->with('data', $request->name);
        }
        
        return redirect('user/database');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($resource)
    {
        $sn = 0;
        $active = 'user';
        $child = 'admi';
        $articles_count = $this->getContentCount();
        
        if (is_numeric(trim($resource))) {
            $searchResult = $this->showById(trim($resource));
        return view('admin.admins.show_user', compact(['searchResult', 'resource', 'sn', 'active', 'child', 'articles_count']));            
        }else{
            $searchResults = $this->showByResource(trim($resource));
            $searchResult = $searchResults[0];
            $resultCount = $searchResults[1];            
        }       
        return view('admin.admins.show_result', compact(['searchResult', 'resource', 'resultCount', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * [getPhoneNumbers description]
     * @return string [description]
     */
    private function getPhoneNumbers($resource)
    {
        $result = '';
        $resultCount = 0;
        $searchResult = Information::get();
        foreach ($searchResult as $key => $value) {
            $resultCount += 1;
            $result .= $value->$resource.',';
            if (!empty($value->mobile_number)) {
                $resultCount += 1;
                $result .= $value->mobile_number.',';
            }
        }
        return [$result, $resultCount];
    }


    /**
     * [getEmails description]
     * @return [type] [description]
     */
    private function getEmails($resource)
    {
        $result = '';
        $resultCount = 0;
        $searchResult = User::get();
        foreach ($searchResult as $key => $value) {
            $resultCount += 1;
            $result .= $value->$resource.',';
        }
        return [$result, $resultCount];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    private function showByResource($resource='')
    {
        if (in_array(trim($resource), ['email', 'phone_number'])){
            if (trim($resource) === 'phone_number') {
                $result = $this->getPhoneNumbers(trim($resource));
            } else {
                $result = $this->getEmails(trim($resource));
            } 
        }else{
            $result = ['What are you trying to do?', false];
        }
        return $result;
    }

    private function showById($resource='')
    {
        $searchResult = [''];
        $searchResult[0] = $this->getUserInfo($resource);
        if (!empty($searchResult[0])) {
            $searchResult[1] = $this->getUserRuslt($resource);
            $searchResult[2] = $this->getUserUndInfo($resource);
            $searchResult[3] = $this->getUserPassport($resource);
            $searchResult[4] = $this->getUserUploadedDoc($resource);
            $searchResult[5] = $this->getUserBankDetail($resource);
        }else{
            $searchResult[0] = $this->getUser($resource);
        }
        return $searchResult;
    }

    private function getUser($resource='')
    {
        $User = new UserController;
        return $User->getSearchResult($resource);
    }

    /**
     * [getUserInfo description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserInfo($resource='')
    {
        $UserInfo = new InformationController;
        return $UserInfo->getSearchResult($resource);
    }

    /**
     * [getUserRuslt description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserRuslt($resource='')
    {
        $UserResult = new ResultController;
        return $UserResult->getSearchResult($resource);
    }

    /**
     * [getUserUndInfo description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserUndInfo($resource='')
    {
        $UserUndInfo = new UndergraduateController;
        return $UserUndInfo->getSearchResult($resource);
    }

    /**
     * [getUserPassport description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserPassport($resource='')
    {
        $UserPassport = new UserPassportController;
        return $UserPassport->getSearchResult($resource);
    }

    /**
     * [getUserUploadedDoc description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserUploadedDoc($resource='')
    {
        $UserDocument = new UserDocumentController;
        return $UserDocument->getSearchResult($resource);
    }

    /**
     * [getUserBankDetail description]
     * @param  string $resource [description]
     * @return [type]           [description]
     */
    private function getUserBankDetail($resource='')
    {
        $UserBankDetail = new BankController;
        return $UserBankDetail->getSearchResult($resource);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $database = DataControl::findOrFail($id);
        if($request['active'] === null){
            $request['active'] = '0';
        }
        $database->update($request->all());
        return redirect('user/database');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateAll(Request $request, $id)
    {
        $database = DataControl::get();
        foreach ($database as $key => $value) {
            if($request['active'] === null){
                $request['active'] = '0';
            }
            $this->updateOneByOne($value->active, $request->active);
        }
        $database->update($request->all());
        return redirect('user/database');
    }


    /**
     * [getTableSate description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getTableSate($value='')
    {
        $tableStates = DataControl::where('name', $value)->get();
        if (count($tableStates)) {
            return $tableStates[0]->active;
        }else{
           return 0;
        }        
        //return $tableState->active;
    }

    /**
     * [updateOneByOne description]
     * @param  [type] $value->active   [description]
     * @param  [type] $request->active [description]
     * @return [type]                  [description]
     */
    private function updateOneByOne($value, $request)
    {
        return true;
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
