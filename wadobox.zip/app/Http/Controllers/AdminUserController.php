<?php

namespace App\Http\Controllers;

use App\User;
use Validator;

use Illuminate\Http\Request;
use App\Http\Requests\UserRequest;

use App\Http\Requests;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ArticleController;

use Auth;

class AdminUserController extends Controller
{
    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function postRegister(Request $request)
    {
        return $this->register($request);
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        $validator = $this->validator($request->all());

        if ($validator->fails()) {

            $this->throwValidationException(
                $request, $validator
            );
        }

        return $this->createNew($request->all()); 
    }

    /**
     * Get the guard to be used during registration.
     *
     * @return string|null
     */
    protected function getGuard()
    {
        return property_exists($this, 'guard') ? $this->guard : null;
    }

    /////////////////........................////////////////////////////


    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name'    => 'required|max:255',
            'last_name'     => 'required|max:255',
            'email'         => 'required|email|max:255|unique:users',
            'password'      => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function createNew(array $data)
    {
        if (Auth::user()) {
            $data['admin'] = $data['active'] = 1;
        } else {
            $data['admin'] = $data['active'] = 0;
        }
        
        return User::create([
            'first_name'    => $data['first_name'],
            'last_name'     => $data['last_name'],
            'email'         => $data['email'],
            'password'      => bcrypt($data['password']),
            'admin'         => $data['admin'],
            'active'        => $data['active'],
        ]);
    }

    ///////////////////////////////////////////////////////////////////
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->register($request);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->register($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::findOrFail($id);
        $articles_count = $this->getContentCount();        
        return view('admin.admins.show', compact(['user', 'image', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        $articles_count = $this->getContentCount();
        return view('admin.admins.edit', compact(['user', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {
      $user = User::findOrFail($id);
      if($request['active'] === null){
        $request['active'] = '0';
      }
      if($request['admin'] === null){
        $request['admin'] = '0';
      }
      $user->update($request->all());
      return redirect('admin/admins');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::where('ids', $id)->delete();
        // ................both method dose the thing................
        // $user = new UserController;
        // $user->destroy($table = 'users', $key = "id", $id);
        return redirect('admin/admins');
    }
}
