<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Subscirbe;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\SubscirbeController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

class SubscriberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subscirbe = new SubscribeController;
        $subscirberList = $subscirbe->getSubscribeList();
        $sn = 0;
        $active = 'subs';
        $child = 'alls';
        $articles_count = $this->getContentCount();
        return view('admin.subscribers.index', compact(['subscirberList', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id='')
    {
        // $url = $request->path();
        // $list = $this->getList($url);
        // $user = new UserController;
        // $userList = $user->getUserList($list);
        // return view('admin.users.index', compact(['userList']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
