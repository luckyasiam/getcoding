<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\HttpResponse;

use App\User;
use App\Article;
use App\UserDocument;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\UserDocumentRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\DatabaseController;
use Carbon\Carbon;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;



use Auth;
use DB;

class UserDocumentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active = 'docu';
        $active_menu = 'Apply Now';
        $menuList = $this->getMenulist();
        $label = $this->getLabel();
        $about = $this->getAboutUsContent();
        $data = $this->validateUserRequest(Auth::user()->id);
        if ($data && count($data)) {
            $sn = 0;
            return view('users.uploaded_doc.index', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label', 'sn']));
        } else {
            return view('users.uploaded_doc.index', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
        }
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }


    /**
     * [getStatus description]
     * @return [type] [description]
     */
    private function getStatus()
    {
        $status = new DatabaseController;
        return $status->getTableSate('user_documents');
    }


    /**
     * [getMenulist description]
     * @return [type] [description]
     */
    private function getMenulist()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getLabel description]
     * @return [type] [description]
     */
    private function getLabel()
    {        
        $article = new ArticleController;
        return $article->getLabel();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($this->getStatus()) {
            //check if incomming request has file.
            if ($request->file('file')) {
                ///store new file to starage.
                $filename = time().$request->file('file')->hashName();
                $moved = Storage::disk('local')->put($filename, file_get_contents($request->file('file')->getRealPath()));
                // store to database record file.
                if ($moved) {
                    $user_document = new UserDocument();
                    $user_document->file_name = $filename;
                    $user_document->mime = $request->file('file')->getClientMimeType();
                    $user_document->file_category = $request->input('category');
                    $user_document->original_file_name = $request->file('file')->getClientOriginalName();
                    $saved = Auth::user()->user_document()->save($user_document);
                    if ($saved) {
                        return redirect('users/uploaded_doc')->with('message', 'Successfully uploaded');
                    } else {
                        return redirect()->back()->with('message', 'Error sending file to server');
                    }            
                } else {
                    return redirect()->back()->with('message', 'Error uploading file to storage disk');
                }
            } else {
                return redirect()->back()->with('message', 'You are trying to be smart');
            } 
        } else {
            return redirect('users/uploaded_doc')->with('message', 'Registration Closed by Admin');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = $this->validateUserRequest($id, 1);
        if ($data && count($data)) {
            $active = 'docu';
            $active_menu = 'Apply Now';
            $menuList = $this->getMenulist();
            $label = $this->getLabel();
            $about = $this->getAboutUsContent();
            return view('users.uploaded_doc.show', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
        }elseif ($data === 0) {
            return redirect('/users/uploaded_doc')->with('message', 'Not found or the file you are trying to view does not belong to you.');
        } else {
            return redirect('/users/uploaded_doc')->with('message', 'You dont have any document record to edit');
        } 
    }

    /**
     * [validateUserRequest description]
     * @param  string $request_id [description]
     * @return [type]             [description]
     */
    private function validateUserRequest($request_id='', $check='')
    {
        if ($check && 1) {
            $user = UserDocument::where('id', $request_id)->where('user_id', Auth::user()->id)->take(1)->get();
        } else {
            $user = UserDocument::where('user_id', $request_id)->get();
        }
        if (count($user)) {             
            if ($user[0]->user_id === Auth::user()->id) {
                if ($check && 1) {
                   return $user[0];
                }else{
                    return $user;  
                }
            } else {
                return 0;
            }
        } else {
            return false;
        }        
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) {            
                $active = 'docu';
                $active_menu = 'Apply Now';  
                $menuList = $this->getMenulist();
                $label = $this->getLabel();
                $about = $this->getAboutUsContent();
                return view('users.uploaded_doc.edit', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
            } else {
                return redirect('/users/uploaded_doc')->with('message', 'You dont have a document to edit');
            } 
        } else {
            return redirect()->back()->with('message', 'Edit Closed by Admin');
        } 
    }

     /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) {  
                //check if incomming request has file.
                if ($request->file('file')) {
                    // delete old file if exist from storage.
                    if (Storage::disk('local')->exists($data->file_name)) {
                        Storage::delete($data->file_name);
                    }
                    ///store new file to starage.
                    $filename = time().$request->file('file')->hashName();
                    $moved = Storage::disk('local')->put($filename, file_get_contents($request->file('file')->getRealPath()));
                    // update database record file.
                    if ($moved) {
                        $user_passport = new UserDocument();
                        $update = Auth::user()
                            ->user_document()
                            ->where('user_id', Auth::user()->id)
                            ->update([
                                'file_name'          => $filename,
                                'mime'               => $request->file('file')->getClientMimeType(),
                                'file_category'      => $request->input('category'),
                                'original_file_name' => $request->file('file')->getClientOriginalName(),
                        ]);
                        if ($update) {
                            return redirect('users/uploaded_doc')->with('message', 'Successfully Updated');
                        } else {
                            return redirect()->back()->with('message', 'Error update file to server');
                        }            
                    } else {
                        return redirect()->back()->with('message', 'Error uploading file to storage disk');
                    }
                }else{
                    return redirect()->back()->with('message', 'File not found');
                }
            } else {
                return redirect('/users/uploaded_doc')->with('message', 'You dont have any document record to edit');
            }
        } else {
            return redirect('users/uploaded_doc')->with('message', 'Edit Closed by Admin');
        }         
    }


    /////////////////////////////////////
    /**
     * [getUserImage description]
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    public function getUserDocument($filename)
    {
        $data = $this->validateUserRequest(Auth::user()->id, 1);
        if ($data && count($data)) {
            $file = Storage::disk('local')->get($filename); 
            return response($file, 200)
                  ->header('Content-Type', $data->mime);
        } else {
            return redirect('users/uploaded_doc')->with('message', 'You are only allowed to view your data');
        }         
    }
    ////////////////////////////////////////////

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //////////////////////////////////////////////////////////
    
    /**
     * [getSearchResult description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getSearchResult($value='')
    {
        return DB::table('user_documents')->where('user_id', $value)->get();
    }
}
