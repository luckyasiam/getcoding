<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;
use App\Http\Requests;
use App\Http\Requests\ArticleRequest;
use App\Http\Requests\ArticleImageRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ArticleImageController;
use App\Http\Controllers\LabelController;
use App\Http\Controllers\PaginationController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;

use Auth;
use DB;


class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $sn = 0;
      $child = 'alla';
      $active = 'arti';
      $articles_count = $this->getContentCount();
      $articles = Article::latest('published_at')->published()->get();
      return view('admin.articles.index', compact(['articles', 'sn', 'active', 'child', 'articles_count']));      
    }


    /**
     * [getLabel description]
     * @return array of label
     */
    public function getLabel()
    {
      $label = new labelController;
      return $label->getLabel($this->getContent());
    }

    /**
     * [getContent description]
     * @return [type] [description]
     */
    public function getContent()
    {
      return Article::latest('published_at')->published()->get();
    }

    /**
     * [getPaginatedContent description]
     * @return [type] [description]
     */
    public function getPaginatedContent($menu = '', $id='')
    {
      if (($menu !== '') && ($id === '')) {
        return Article::latest('published_at')->published()->where('tag', $menu)->paginate(10);
      } elseif (($menu == '') && ($id !== '')) {
        return Article::latest('published_at')->where('id', $id)->paginate(10);
      } else{
        return Article::latest('published_at')->published()->paginate(10);
      }
      
    }  

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $sn = 0;
      $child = 'crea';
      $active = 'arti';
      $articles_count = $this->getContentCount();
      return view('admin.articles.create', compact(['articles', 'sn', 'active', 'child', 'articles_count']));
    }

     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ArticleRequest $request)
    { 
        if ($this->getPermission()) {
            //check if incomming request has file.            
            if ($request->file('file')) {
                ///store new file to starage.
                $image = time().$request->file('file')->hashName();
                $moved = Storage::disk('local')->put($image, file_get_contents($request->file('file')->getRealPath()));
                // store article image name and input to database
                if ($moved) {
                    $article = new Article();
                    $article->title = $request->input('title');
                    $article->tag = $request->input('tag');
                    $article->body = $request->input('body');
                    $article->image = $image;
                    $article->image_name = $request->file('file')->getClientOriginalName();
                    $article->mime = $request->file('file')->getClientMimeType();
                    $article->active = $request->input('active') ? 1 : 0;
                    $article->status = 0;
                    $article->reads = 0;
                    $article->published_at = $request->input('active') ? Carbon::now() : '0';
                    $saved = Auth::user()->article()->save($article);
                    if ($saved) {
                        return redirect('admin/articles/')->with('message', 'Successfully uploaded');
                    } else {
                        return redirect()->back()->with('message', 'Error sending file to server');
                    }            
                } else {
                    return redirect()->back()->with('message', 'Error uploading file to storage disk');
                }
            }else{
              return redirect()->back()->withInput()->with('message', 'Bad image or File not found');
            } 
        } else {
            return redirect('admin/articles/')->with('message', 'You dont have the privileges to post as Admin');
        }
    }


    // $id = DB::table('users')->insertGetId($article);

    /**
     * Get the specified resource.
     *
     * @param  \Illuminate\Http\ArticleImageRequest
     * @return \Illuminate\Http\Response
     */
    public function save_article_image(ArticleImageRequest $request, $article_id = '')
    {
        $input = 'article_image';
        $articleImage= new ArticleImageController;
        return $articleImage->store($request, $input, $article_id);        
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $article = Article::findOrFail($id);
      $sn = 0;
      $child = 'crea';
      $active = 'arti';
      $articles_count = $this->getContentCount();
        // $image = $image->toArray();     
        return view('admin.articles.show', compact(['article', 'sn', 'active', 'child', 'articles_count']));
    }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function showContent($id)
  {
    return Article::find($id);            
  }

  
  /**
   * Get permission to edit
   * @return [type] [description]
   */
  private function getPermission()
  {
      return true;
  }

  /**
   * Get required article from DB.
   * @param  [type] $id [description]
   * @return [type]     [description]
   */
  private function getArticle($id)
  {
      $article= Article::find($id);
      return $article;
  }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($this->getPermission()) {
            $article= $this->getArticle($id);
            if ($article&& count($article)) { 
                $sn = 0;
                $message = '';
                $child = 'crea';
                $active = 'arti';
                $articles_count = $this->getContentCount();
                return view('admin.articles.edit', compact(['article', 'sn', 'active', 'child', 'articles_count', 'message']));
            } else {
                return redirect()->back()->with('message', 'Error getting file.');
            } 
        } else {
            return redirect()->back()->with('message', 'You dont have admin permission!');
        } 
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { 
        if ($this->getPermission()) {
            $article = $this->getArticle($id);
            if (($article) && (count($article))) {  
                //check if incomming request has file.
                if ($request->file('file')) {
                    // delete old file if exist from storage.
                    if (Storage::disk('local')->exists($article->image)) {
                        Storage::delete($article->image);
                    }
                    ///store new file to starage.
                    $image = time().$request->file('file')->hashName();
                    $moved = Storage::disk('local')->put($image, file_get_contents($request->file('file')->getRealPath()));
                    // update articlebase record file.
                    if ($moved) {
                        $article = new Article();
                        $updated = Auth::user()
                            ->article()
                            ->where('id', $id)
                            ->update([
                                'title'         => $request->input('title'),
                                'tag'           => $request->input('tag'),
                                'body'          => $request->input('body'),
                                'image'         => $image,
                                'image_name'    => $request->file('file')->getClientOriginalName(),
                                'mime'          => $request->file('file')->getClientMimeType(),
                                'active'        => $request->input('active') ? 1 : 0,
                                'status'        => 0,
                                'reads'         => 0,
                                'published_at'  => $request->input('active') ? Carbon::now() : '0'
                        ]);
                        if ($updated) {
                        return redirect('admin/articles/')->with('message', 'Successfully updated');
                        } else {
                            return redirect()->back()->with('message', 'Error sending file to server');
                        }            
                    } else {
                        return redirect()->back()->with('message', 'Error uploading file to storage disk');
                    }
                }else{
                  return redirect()->back()->withInput()->with('message', 'The picture/image is not a valid one');
                } 
            } else {
                return redirect('admin/articles/')->with('message', 'Error retrieving file from database');
            }
        } else {
            return redirect('admin/articles/')->with('message', 'You dont have the privileges to post as Admin');
        }         
    }




  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    Article::where('id', $id)->delete();
    return redirect('admin/articles');
  }


  /**
   * [getUserImage description]
   * @param  [type] $filename [description]
   * @return [type]           [description]
   */
  public function getArticleImage($filename)
  {
      $article= $this->getArticle($_GET['id']);
      if (($article->image === $filename) && ($article&& count($article))) {
          $file = Storage::disk('local')->get($article->image); 
          return response($file, 200)
                ->header('Content-Type', $article->mime);
      } else {
          return redirect('/')->with('message', 'STOP! what are you trying to do?');
      }         
  }


  ///////////////////////////////////////////////////////////////////////////////////////////////
    // UnUsed functions   
  public function getPage($page)
  {
    $idCount = $this->getIdCount($page);
    if ($idCount) {
      return Article::latest('published_at')->published()->where('id', '<', $idCount)->paginate(10);
    } else {
      return false;
    }   
  }

  public function getMenuPage($menu)
  {
    $idCount = $this->getMenuIdCount($menu);
    if ($idCount) {
      return Article::latest('published_at')->published()->where(['tag' => $menu, ])->paginate(10);
    } else {
      return false;
    }   
  }
      
  public function getPagination()
  {
    $pagination = new PaginationController;      
    return $pagination->getPagination($this->getContent());
  }

  public function getMenuPagination($menu)
  {
    $pagination = new PaginationController;
    return $pagination->getMenuPagination($this->getMenuContent($menu));
  }
    
  public function getMenuContent($menu)
  {
    return Article::latest('published_at')->published()->where('tag', $menu)->get();
  }

  public function getContentCount($menu = '')
  {
  if ($menu !== '') {
     return count(Article::where($menu, $menu)->get());
  } else {
     return count(Article::get());
  }    
  }

  public function getIdCount($page = '')
  {    
    if (($this->getContentCount() - ($page - 9)) > 0) {
      return $this->getContentCount() - ($page - 9);
    } else {
      return false;
    }
  }

  public function getMenuIdCount($page = '', $menu = '')
  {    
    if (($this->getContentCount($menu) - ($page - 9)) > 0) {
      return $this->getContentCount() - ($page - 9);
    } else {
      return false;
    }
  }
  ////////////////// used function end //////////////////////

}
