<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Result;
use App\Article;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\ResultRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\DatabaseController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Auth;
use DB;

class ResultController extends Controller
{   
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active = 'ssce';
        $active_menu = 'Apply Now';
        $menuList = $this->getMenulist();
        $label = $this->getLabel();
        $about = $this->getAboutUsContent();
        $data = $this->validateUserRequest(Auth::user()->id);
        if ($data && count($data)) {
            return redirect()->action('ResultController@show', $this->savedId());
        } else {
            return view('users.ssce_result.index', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
        }
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }



    /**
     * [getStatus description]
     * @return [type] [description]
     */
    private function getStatus()
    {
        $status = new DatabaseController;
        return $status->getTableSate('results');
    }


    /**
     * [getMenulist description]
     * @return [type] [description]
     */
    private function getMenulist()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getLabel description]
     * @return [type] [description]
     */
    private function getLabel()
    {        
        $article = new ArticleController;
        return $article->getLabel();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * [savedId description]
     * @return [type] [description]
     */
    private function savedId()
    {
        $data = $this->validateUserRequest(Auth::user()->id);
        return $data->id;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ResultRequest $request)
    {
        if ($this->getStatus()) {
            $data = new Result($request->all());
            Auth::user()->result()->save($data);
            return redirect()->action('ResultController@show', $this->savedId())->with('message', 'Successfully updated');
        } else {
            return redirect('users/ssce_result')->with('message', 'Registration Closed by Admin');
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = $this->validateUserRequest($id, 1);
        if ($data && count($data)) {
            $active = 'ssce';
            $active_menu = 'Apply Now';
            $menuList = $this->getMenulist();
            $label = $this->getLabel();
            $about = $this->getAboutUsContent();
            return view('users.ssce_result.show', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
        } elseif ($data == 0) { //// this message will never display to the users////////////
            return redirect('/users/ssce_result')->with('message', 'You are trying to be smart!');
        } else {    /////////////// this message will only display to the new users////////////
           return redirect('/users/ssce_result')->with('message', 'You dont have a record');
        }  
    }

    /**
     * [validateUserRequest description]
     * @param  string $request_id [description]
     * @return [type]             [description]
     */
    private function validateUserRequest($request_id='', $check='')
    {
        if ($check && 1) {
            $user = Result::where('id', $request_id)->where('user_id', Auth::user()->id)->take(1)->get();
        }else{
            $user = Result::where('user_id', $request_id)->take(1)->get();
        }
        if (count($user)) {             
            if ($user[0]->user_id === Auth::user()->id) {                
                return $user[0];
            } else {
                return 0;
            }
        } else {
            return false;
        }        
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) { 
                $active = 'ssce';
                $active_menu = 'Apply Now';
                $menuList = $this->getMenulist();
                $label = $this->getLabel();
                $about = $this->getAboutUsContent();
                return view('users.ssce_result.edit', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
            } else {
                return redirect('/users/ssce_result')->with('message', 'You dont have a record to edit');
            } 
        } else {
            return redirect()->back()->with('message', 'Edit Closed by Admin');
        }
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) {
                    $data->update($request->all());
                    return redirect()->action('ResultController@show', $id)->with('message', 'Successfully updated');
            } else {
                return redirect('/users/ssce_result')->with('message', 'You dont have a record to edit');
            }            
        } else {
            return redirect()->back()->with('message', 'Edit Closed by Admin');
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    ///////////////////////////////////
    
    /**
     * [getSearchResult description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getSearchResult($value='')
    {
        return DB::table('results')->where('user_id', $value)->get();
    }
}
