<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\ArticleController;

use App\Http\Requests;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sn = 0;
        $child = 'dash';
        $active = 'dash';
        $articles_count = $this->getContentCount();
        return view('admin.index', compact(['article', 'image', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function test()
    {
        $navs = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('admin.admin', compact('navs'));
       
    }



    public function test_create()
    {
        $navs = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('admin.article-old.new-article', compact('navs'));
       
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return 'under construction';
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
