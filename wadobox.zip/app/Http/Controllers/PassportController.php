<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Passport;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\PassportRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MenuController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Auth;

class PassportController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $article = new ArticleController;
        $label = $article->getLabel();
        $data = $this->show(Auth::user()->id);
        $active = 'pass';
        $active_menu = 'Apply Now';
        if ($data) {
            return view('users.passport.show', compact(['menuList', 'data', 'active', 'active_menu', 'label']));
        } else {
            return view('users.passport.index', compact(['menuList', 'data', 'active', 'active_menu', 'label']));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PassportRequest $request)
    {
        $data = new Passport($request->all());
        Auth::user()->passport()->save($data);
        return redirect('users.passport.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = Passport::where('user_id', $id)->take(1)->get();        
        if (count($user)) {
            return $user[0];
        } else {
            return false;
        } 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
