<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ProfileController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.index', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function personal_info()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.personal_info', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function sec_schl_details()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.sec_schl_details', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function ssce_result()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.ssce_result', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function undergraduate()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.undergraduate', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function post_graduate()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.post_graduate', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function passport()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.passport', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function uploaded_doc()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.uploaded_doc', compact('menus'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function bank_details()
    {
        $menus = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        return view('users.bank_details', compact('menus'));
    }
}
