<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Information;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\SearchRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\InformationController;
use App\Http\Controllers\UndergraduateController;
use App\Http\Controllers\UserController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

class ManageUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = new UserController;
        $userList = $user->getUserList();
        $sn = 0;
        $active = 'user';
        $child = 'user';
        $articles_count = $this->getContentCount();
        return view('admin.users.index', compact(['userList', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * [getList description]
     * @param  string $url [description]
     * @return [type]      [description]
     */
    private function getList ($url='')
    {
        if ($url == 'admin/users/all-users') { return 'all'; }
        if ($url == 'admin/users/reg-users') { return 'register'; }
        if ($url == 'admin/users/act-users') { return 'active'; }
    }




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByUrl(Request $request, $id='')
    {
        $url = $request->path();
        $list = $this->getList($url);
        $user = new UserController;
        $userList = $user->getUserList($list);
        $articles_count = $this->getContentCount();
        return view('admin.users.index', compact(['userList', 'articles_count']));
    }


    ////////////////////////////////////////////////////////////////
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->register($request);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createUser()
    {
        $articles_count = $this->getContentCount();
        return view('admin.users.search', compact(['articles_count']));
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->register($request);
    }

    public function findByResource(SearchRequest $request)
    {
        if (in_array($request->search_key, ['institution_name', 'institution_type', 'matric_number', 'jamb_reg_number', 'faculty', 'department', 'current_level', 'entry_mode'])){
            $search = new UndergraduateController;
            $searchResult = $search->getSearchResult($request->search_key, trim($request->search_value));
            if (!empty($searchResult) && count($searchResult)) {
                $index = 0;
                foreach ($searchResult as $result) {
                    $users = Information::find($result->user_id);
                    foreach ($users['original'] as $key => $value) {
                        if (!in_array($key, ['id', 'password', 'remember_token', 'created_at', 'updated_at'])) {
                            $result->$key = $value;
                        }                     
                    }
                    $userList[$index] = $result;
                    $index += 1;
                }
            }else{
                dd('Wrong key value combination');
            }
        } elseif (in_array($request->search_key, ['email', 'state', 'local_govt'])) {
            $search = new InformationController;
            $searchResult = $search->getSearchResult($request->search_key, trim($request->search_value));
            if (!empty($searchResult)) {
                $userList  = $searchResult;
            }elseif ((empty($searchResult)) && ($request->search_key == 'email')) {
                $searchResult = User::where('email', trim($request->search_value))->get();
                if (!empty($searchResult)) {
                    $userList = $searchResult;
                }
            }else{
                dd('Wrong key value combination');
            }
        } else{
            dd('The search value: ' .$request->search_value. ' is not understood');
        }

        if(!empty($searchResult)){
            $sn = 0;
            $active = 'user';
            $child = 'admi';
            $articles_count = new ArticleController;
            $articles_count = $articles_count->getContentCount();
            return view('admin.admins.show_search', compact(['userList', 'sn', 'active', 'child', 'articles_count']));
        }else{
            return $this->create($email);
        }        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        if (empty($user)) {
           $user  = 'what are you trying to do?';
           dd($user);
        }
        $articles_count = $this->getContentCount();
        return view('admin.users.show', compact(['user', 'image', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        $articles_count = $this->getContentCount();
        return view('admin.users.edit', compact(['user', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {
      $user = User::findOrFail($id);
      if($request['active'] === null){
        $request['active'] = '0';
      }

      $user->update($request->all());
      return redirect('admin/users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::where('ids', $id)->delete();
        // ................both method dose the thing................
        // $user = new UserController;
        // $user->destroy($table = 'users', $key = "id", $id);
        return redirect('admin/users');
    }
}
