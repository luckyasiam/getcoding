<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class LabelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function getLabel($contents='')
    {
      $label = ['scholarships' => '', 'bursary' => '', 'jobs' => '', 'it_placement' => '', 'news' => '', 'blog' => '', 'forum' => '', 'education' => '', 'science' => '', 'technology' => '', 'culture' => '', 'sports' => '']; 
      if(count($contents) > 1){
        foreach($contents as $content){
            if($content->tag == 'scholarships'){ $label['scholarships'] += 1;  }
            if($content->tag == 'bursary'){ $label['bursary'] += 1; }
            if($content->tag == 'jobs'){ $label['jobs'] += 1; }
            if($content->tag == 'it-placement'){ $label['it_placement'] += 1; }
            if($content->tag == 'news'){ $label['news'] += 1; }
            if($content->tag == 'blog'){ $label['blog'] += 1; }
            if($content->tag == 'forum'){ $label['forum'] += 1; }
            if($content->tag == 'education'){ $label['education'] += 1; }
            if($content->tag == 'science'){ $label['science'] += 1; }
            if($content->tag == 'technology'){ $label['technology'] += 1; }
            if($content->tag == 'culture'){ $label['culture'] += 1; }
            if($content->tag == 'sport'){ $label['sports'] += 1; }
        }
        return $label;
      }else{
        return $label;
      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
