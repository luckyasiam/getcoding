<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Information;
use App\Result;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\InformationRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MenuController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Auth;
use DB;

class UserController extends Controller
{
    private $path = '';
    private $url = '';
    
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $id='')
    {
        $menu = new MenuController;
        $menuList = $menu->index();
        $url = $request->path();
        $active_menu = 'Apply Now';
        if ($url == 'users' || $url == 'users/application') {
            return view('users.index', compact(['menuList', 'active_menu']));
        } else {
            return view('errors.page_not_found', compact(['menuList', 'url', 'active_menu']));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.reg-form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(InformationRequest $request)
    {
        var_dump($request->path());
        $data = new Information($request->all());
        Auth::user()->information()->save($data);
        return redirect('user/personal_info');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id='')
    {
        $route = ['users/personal_info', 'users/ssce_result', 'users/undergraduate','users/passport', 'users/uploaded_doc', 'users/bank_details'];
        $url = $request->path();       
        $menuList = ['job' => "Jobs", 'schola' => 'Scholarships', 'application' => 'Apply Now', 'about' => 'About Us'];
        if (in_array($url, $route)) {
           return view($url, compact(['menuList', 'data']));
        }elseif ($url == 'users/application') {
           return view('users.index', compact('menuList'));
        } else {
           return view('errors.page_not_found', compact(['menuList', 'url']));
        }
    }

    /**
     * getUserList for active, admin ......
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getUserList($value='')
    {
        if ($value == '') {
            return DB::table('users')->get();
        } else {
            return DB::table('users')->where($value, 1)->get();
        }
        
    }

    /**
     * [getUser description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getUser($key, $value='' )
    {
        if ($value == '') {
            return DB::table('users')->get();
        } else {
            return DB::table('users')->where($key, $value)->get();
        }
        
    }

    /**
     * [getSearchResult description]
     * @param  string $key   [description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getSearchResult($key='', $value='' )
    {
        if (empty($value)) {
            $value = $key;
            $key = 'id';
        }
        //return DB::table('users')->where($key, $value)->find($value); 
        return DB::table('users')->find($value); 
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return Information::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($table, $key, $value)
    {
        DB::table($table)->where($key, $value)->delete();
    }
}
