<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Submission;
use App\Information;
use App\Result;
use App\Undergraduate;
use App\UserPassport;
use App\UserDocument;
use App\Bank;
use App\User;
use App\Http\Requests;
use App\Http\Controllers\DatabaseController;
use App\Http\Controllers\InformationController;
use App\Http\Controllers\ArticleController;
use App\Http\Requests\SubmintionRequest;

use Auth;
use DB;


class SubmissionController extends Controller
{   


/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }

    /**
     * [getStatus description]
     * @return [type] [description]
     */
    private function getStatus()
    {
        $status = new DatabaseController;
        return $status->getTableSate('information');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $active = 'data';
        $child = 'rest';
        $articles_count = $this->getContentCount(); 
        return view('admin.users.reset_search', compact(['active', 'child', 'articles_count']));
    }


    /**
     * [serchUser description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function searchUser(Request $request)
    {
        $active = 'data';
        $child = 'rest';
        $user = $this->getUser($request);
        $articles_count = $this->getContentCount(); 
        return view('admin.admins.reset_user', compact(['user', 'active', 'child', 'articles_count']));
    }

    /**
     * [getUser description]
     * @param  [type] $request [description]
     * @return [type]          [description]
     */
    private function getUser($request)
    {         
        $user = User::where('email', $request->input('email'))->take(1)->get();
        return $user[0];
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($this->getStatus()) {
            $tableList = new DatabaseController;
            $tableList = $tableList->getAllTables();
            foreach ($tableList as $key => $table) {
                $user_saved_doc = $this->userHasSaveDoc($table->name, Auth::user()->id);
                if ($user_saved_doc) {
                    $submitted = $this->setSubmit($table->name, Auth::user()->id, $user_saved_doc,  $state = 1);
                } else {
                    $redirect_url = $this->tableToUrl();
                    return redirect('/users/'.$redirect_url[$table->name])->with('message', 'This users '.$table->name.' details have not been saved.');
                }
            }     
            $request['status'] = 1;
            $request['active'] = 1;
            $data = new Submission($request->all());
            Auth::user()->submission()->save($data);
            return redirect()->action('BankController@show', Auth::user()->id)->with('message', 'Application was successfully saved');
        } else {
            return redirect('users/personal_info')->with('message', 'Registration Closed by Admin');
        }
    }

    private function checkSavedStatus($table, $user_id)
    {
        $saved_data = DB::table($table)->where('user_id', $user_id)->take(1)->get();
        if (count($saved_data)) {
            return $saved_data;            
        } else {
            return false;
        }
    }

    /**
     * [setSubmit description]
     * @param [type] $table   [description]
     * @param string $user_id [description]
     * @param string $state   [description]
     */
    private function setSubmit($table, $user_id='', $user_saved_doc, $state='')
    {
        $status = $user_saved_doc->status;
        return $this->setStates($table, $status, $user_id, $column='status', $state);        
    }


    /**
     * [setSubmit description]
     * @param [type] $table   [description]
     * @param string $user_id [description]
     * @param string $state   [description]
     */
    private function setActive($table, $user_id='', $user_saved_doc, $state='')
    {
        $status = $user_saved_doc->active;
        return $this->setStates($table, $status, $user_id, $column='active', $state);
    }


    private function setStates($table, $status='', $user_id='', $column, $state='')
    {
        if ($status && $state) {
            return true;
        } else {
            $updateTable = $this->initializeTable($table);
            if ($updateTable) {
                return $updateTable->where('user_id', $user_id)->update([$column => $state]);
            } else {
                dd('What are you trying to do?');
            }
        }
    }

    /**
     * [userHasSaveDoc description]
     * @param  [type] $table   [description]
     * @param  [type] $user_id [description]
     * @return [type]          [description]
     */
    private function userHasSaveDoc($table, $user_id)
    {
        $user_saved_doc = $this->checkSavedStatus($table, $user_id);
        if ($user_saved_doc ) {
            return $user_saved_doc[0];
        } else {
            return false;
        }
    }

    /**
     * [setSubmit description]
     * @param [type] $table   [description]
     * @param string $user_id [description]
     * @param string $state   [description]
     */
    private function resetActiveAndSubmit($table, $action, $user_id='', $user_saved_doc='', $state='')
    {
        if ($action === 'status') {
            return $this->setSubmit($table, $user_id, $user_saved_doc, $state);
        } elseif ($action === 'active') {
            return $this->setActive($table, $user_id, $user_saved_doc, $state);
        }else {
            $this->setActive($table, $user_id, $user_saved_doc, $state);
            $this->setSubmit($table, $user_id, $user_saved_doc, $state);                
            return true;
        }    
    }


    private function initializeTable($table='')
    {
        switch ($table) {
            case 'information'      : return new Information; break;
            case 'results'          : return new Result; break;
            case 'undergraduates'   : return new Undergraduate; break;
            case 'user_passports'   : return new UserPassport; break;
            case 'user_documents'   : return new UserDocument; break;
            case 'banks'            : return new Bank; break;            
            case 'users'            : return new User; break;            
            default: return false; break;
        }
    }

    
    /**
     * [tableKeys description]
     * @return [type] [description]
     */
    private function tableKeys()
    {
        return ['banks' => 'Bank', 'documents' => 'Document', 'information' => 'Information', 'results' => 'Result', 'undergraduates' => 'Undergraduate', 'user_documents' => 'UserDocument', 'user_passports' => 'UserPassport'];
    }

    
    /**
     * [tableToUrl description]
     * @return [type] [description]
     */
    private function tableToUrl()
    {
        return ['banks' => 'bank_details', 'information' => 'personal_info', 'results' => 'ssce_result', 'undergraduates' => 'undergraduate', 'user_documents' => 'uploaded_doc', 'user_passports' => 'passport'];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return redirect('/');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return redirect('/');
    }

    /**
     * Check if the user is admin and active
     * @return [type] [description]
     */
    private function getPermission()
    {
        return (Auth::user()->admin && Auth::user()->active);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $active = 'data';
        $child = 'rest';
        $user = $this->getUser($request);
        $articles_count = $this->getContentCount(); 
        if ($this->getPermission()) {           
            //// Select action to perform
            if ($request->input('action') === 'all') {
                $count = 0;
                $status = DB::table($request->table)->select('user_id as id', 'active')->get();
                foreach ($status as $key => $value) {
                    $user_saved_doc = $this->userHasSaveDoc($request->table, $value->id);            
                    if ($user_saved_doc) {
                        $update = $this->resetActiveAndSubmit($request->table, $request->action, $value->id, $user_saved_doc, $request->state);
                        if ($update) {
                            $count += 1;
                        }
                    }
                }
                return view('admin.admins.reset_user', compact(['user', 'active', 'child', 'articles_count']))->withErrors(['updatd_error' => $count.' User(s) out of '.count($status). ' updated']);
            } else {
                $user_saved_doc = $this->userHasSaveDoc($request->table, $id);
                if ($user_saved_doc) {
                    $update =  $this->resetActiveAndSubmit($request->table, $request->action, $id, $user_saved_doc, $request->state);
                    if ($update) {
                        return view('admin.admins.reset_user', compact(['user', 'active', 'child', 'articles_count']))->withErrors(['updatd_error' => 'Successfully updated']);
                    }else{
                        return view('admin.admins.reset_user', compact(['user', 'active', 'child', 'articles_count']))->withErrors(['updatd_error' => 'Updated failed']);
                    }
                }else{
                    return view('admin.admins.reset_user', compact(['user', 'active', 'child', 'articles_count']))->withErrors(['updatd_error' => 'Error: User has no saved '.$request->table.' data']);
                }
            }
            if ($update) {
                return view('admin.admins.reset_user')->withInput()->with('message', 'Successfully updated');
            }else{
                return view('admin.admins.reset_user')->withInput()->with('message', 'Updated failed');
            }
        
       } else {
           return view('admin.admins.reset_user')->withInput()->with('message', 'You dont have the permission to perform this operation');
       }
                      
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
