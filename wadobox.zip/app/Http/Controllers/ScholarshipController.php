<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;
use App\Http\Requests;

class ScholarshipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active_menu = 'Scholarships';
        $label = $this->getLabel();
        $menuList = $this->getMenuList();
        $about = $this->getAboutUsContent();
        $contents = $this->getContent($active_menu);
        return view('index', compact(['menuList', 'active_menu', 'contents', 'about', 'label']));
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }

    /**
     * [getMenuList description]
     * @return [type] [description]
     */
    private function getMenuList()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getContent description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getContent($content, $id='')
    {
        if ($id) {
            return Article::find($id);
        } else {            
            $article = new ArticleController;
            return $article->getPaginatedContent(strtolower($content));
        }
    }

    /**
     * [getLabel description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function getLabel()
    {
        $article = new ArticleController;
        return $article->getLabel();
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $active_menu = 'Scholarships';
        $label = $this->getLabel();
        $menuList = $this->getMenuList();
        $about = $this->getAboutUsContent();
        $contents = $this->getContent(0, $id);
        return view('pages.scholarship.show', compact(['menuList', 'active_menu', 'contents', 'about', 'label', 'about']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
