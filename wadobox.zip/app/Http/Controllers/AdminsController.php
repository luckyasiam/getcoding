<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ArticleController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

class AdminsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = new UserController;
        $userList = $user->getUserList('admin');
        $sn = 0;
        $active = 'user';
        $child = 'admi';
        $articles_count = $this->getContentCount();
        return view('admin.admins.index', compact(['userList', 'sn', 'active', 'child', 'articles_count']));
    }

    /**
     * [getContentCount description]
     * @return [type] [description]
     */
    public function getContentCount()
    {
        $articles_count = new ArticleController;
        return $articles_count->getContentCount();
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($email='')
    {
        $articles_count = $this->getContentCount();
        return view('admin.admins.create', compact(['registered_user', 'sn', 'active', 'child','email', 'articles_count']));
    }

     /**
     * Show the form to fine a user.
     *
     * @return \Illuminate\Http\Response
     */
    public function createUser()
    {
        $articles_count = $this->getContentCount();
        return view('admin.admins.search', compact(['articles_count']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addAdmin(Request $request)
    {
        $file = $this->getInputFile($request);
        $article_id = Auth::user()->article()->insertGetId($file);
        $save_image = $this->save_article_image($request, $article_id);
        if ($save_image) {
            return redirect('admin/articles/');
        } else {
            echo "error has occure";
            return redirect('admin/articles/create');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByEmail(Request $request)
    {
        $user = new UserController;
        $email = $request->email;
        $user = $user->getUser('email', $email);        
        if(count($user)){
             $sn = 0;
            $active = 'user';
            $child = 'admi';
            $user = $user[0];
            $articles_count = new ArticleController;
            $articles_count = $articles_count->getContentCount();
            return view('admin.admins.edit', compact(['user', 'sn', 'active', 'child', 'articles_count']));
        }else{
            return $this->create($email);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
