<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Bank;
use App\Article;
use App\Http\Requests;
use App\Http\Requests\UserRequest;
use App\Http\Requests\BankRequest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\DatabaseController;
use Illuminate\HttpResponse;
use Carbon\Carbon;

use Auth;
use DB;

class BankController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active = 'bank';
        $active_menu = 'Apply Now';
        $menuList = $this->getMenulist();
        $label = $this->getLabel();
        $about = $this->getAboutUsContent();
        $data = $this->validateUserRequest(Auth::user()->id);
        if ($data && count($data)) {
            return redirect()->action('BankController@show', $this->savedId());
        } else {
            return view('users.bank_details.index', compact(['menuList', 'data', 'active', 'about', 'active_menu', 'label']));
        }
    }

    /**
     * Get the about us content.
     * @return [type] [description]
     */
    private function getAboutUsContent()
    {
        $content = Article::where('tag', 'about_us')->take(1)->get();
        if (count($content)) {               
            return $content[0];
        }else{
            return 0;
        }
    }

    /**
     * [getStatus description]
     * @return [type] [description]
     */
    private function getStatus()
    {
        $status = new DatabaseController;
        return $status->getTableSate('banks');
    }


    /**
     * [getMenulist description]
     * @return [type] [description]
     */
    private function getMenulist()
    {
        $menu = new MenuController;
        return $menu->index();
    }

    /**
     * [getLabel description]
     * @return [type] [description]
     */
    private function getLabel()
    {        
        $article = new ArticleController;
        return $article->getLabel();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    /**
     * [savedId description]
     * @return [type] [description]
     */
    private function savedId()
    {
        $data = $this->validateUserRequest(Auth::user()->id);
        return $data->id;
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
     public function store(BankRequest $request)
    {
        if ($this->getStatus()) {
            $data = new Bank($request->all());
            Auth::user()->bank()->save($data);
            return redirect()->action('BankController@show', $this->savedId())->with('message', 'Successfully updated');
        } else {
            return redirect('users/bank_details')->with('message', 'Registration Closed by Admin');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = $this->validateUserRequest($id, 1);       
        if ($data && count($data)) {
            $active = 'bank';
            $active_menu = 'Apply Now';
            $menuList = $this->getMenulist();
            $label = $this->getLabel();
            $about = $this->getAboutUsContent();
            return view('users.bank_details.show', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
        } elseif ($data == 0) { //// this message will never display to the users////////////
            return redirect('/users/bank_details')->with('message', 'You are trying to be smart!');
        } else {    /////////////// this message will only display to the new users////////////
           return redirect('/users/bank_details')->with('message', 'You dont have a record');
        }  
    }


    /**
     * [validateUserRequest description]
     * @param  string $request_id [description]
     * @return [type]             [description]
     */
    private function validateUserRequest($request_id='', $check='')
    {
        if ($check && 1) {
            $user = Bank::where('id', $request_id)->where('user_id', Auth::user()->id)->take(1)->get();
        }else{
            $user = Bank::where('user_id', $request_id)->take(1)->get();
        }
        if (count($user)) {             
            if ($user[0]->user_id === Auth::user()->id) {                
                return $user[0];
            } else {
                return 0;
            }
        } else {
            return false;
        }        
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) { 
                $active = 'bank';
                $active_menu = 'Apply Now';
                $menuList = $this->getMenulist();
                $about = $this->getAboutUsContent();
                $label = $this->getLabel();
                 return view('users.bank_details.edit', compact(['menuList', 'data', 'about', 'active', 'active_menu', 'label']));
            } else {
                return redirect('/users/bank_details')->with('message', 'You dont have a record to edit');
            } 
        } else {
            return redirect()->back()->with('message', 'Edit Closed by Admin');
        } 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($this->getStatus()) {
            $data = $this->validateUserRequest($id, 1);
            if ($data && count($data)) { 
                $data->update($request->all());
                return redirect()->action('BankController@show', $id)->with('message', 'Successfully updated');
            } else {
                return redirect('/users/bank_details')->with('message', 'You dont have a record to edit');
            }            
        } else {
            return redirect()->back()->with('message', 'Edit Closed by Admin');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    ///////////////////////////////////////////////////////
    
    /**
     * [getUserPassport description]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getSearchResult($value='')
    {
        return DB::table('banks')->where('user_id', $value)->get();
    }
}
