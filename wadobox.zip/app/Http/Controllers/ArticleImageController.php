<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\ArticleImage;
use App\Http\Requests;
use Illuminate\HttpResponse;
use App\Http\Requests\UserRequest;
use App\Http\Requests\ArticleImageRequest;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

use Auth;
use Storage;


class ArticleImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($request, $input, $article_id = '')
    {      
        $file_name = $this->getFilename($request, $input);
        $distination = public_path() . '/' . 'article_images';
        $moved = $this->moveFile($request, $input, $distination, $file_name);
        if ($moved) {
            $file = $this->getFile($request, $input);
            $extension = $file->getClientOriginalExtension();
            $article_image = new ArticleImage();
            $article_image->article_id = $article_id;
            $article_image->file_name = $file->getFilename(). '.' .$extension;
            $article_image->mime = $file->getClientMimeType();
            $article_image->original_file_name = $file->getClientOriginalName();
            return Auth::user()->article_image()->save($article_image);
        } else {
            return false;
        }
        
    }

    /**
     * [getFilename description]
     * @param  [type] $request [description]
     * @return [type]          [description]
     */
    public function getFilename($request, $input = '')
    {
        $file = $this->getFile($request, $input); 
        $extension = $file->getClientOriginalExtension();       
        return $file->getFilename(). '.' .$extension;        
    }

    public function getFile($request, $input = '')
    {
        return $request->file($input);
    }

    /**
     * [moveFile description]
     * @param  [type] $distination [description]
     * @param  [type] $file_name   [description]
     * @return [type]              [description]
     */
    private function moveFile($request, $input, $distination, $file_name)
    {
        $file = $this->getFile($request, $input);
        return $file->move($distination, $file_name);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return ArticleImage::where('article_id', $id)->get();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
