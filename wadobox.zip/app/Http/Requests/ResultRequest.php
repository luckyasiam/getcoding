<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;
use Auth;

class ResultRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ((Auth::user())) {
            return true;
        } else {
            return false;
        }
        
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        'school_name'       => 'required|min:3',
        'school_type'       => 'required|min:3',
        'admission_year'    => 'required|min:3',
        'graduation_year'   => 'required|min:3',
        'english'           => 'required|min:1',
        'mathematics'       => 'required|min:1',
        'subject3'          => 'required|min:3',
        'subject3_grade'    => 'required|min:1',
        'subject4'          => 'required|min:3',
        'subject4_grade'    => 'required|min:1',
        'subject5'          => 'required|min:3',
        'subject5_grade'    => 'required|min:1',
        ];
    }
}
