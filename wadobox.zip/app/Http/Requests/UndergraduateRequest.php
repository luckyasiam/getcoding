<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

use Auth;

class UndergraduateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ((Auth::user())) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        'institution_name'  => 'required|min:3',
        'institution_type'  => 'required|min:3',
        'matric_number'     => 'required|min:3',
        'jamb_reg_number'   => 'required|min:3',
        'jamb_score'        => 'required|min:3',
        'faculty'           => 'required|min:3',
        'department'         => 'required|min:3',
        'course'            => 'required|min:3',
        'duration'          => 'required',
        'entry_year'        => 'required|min:3',
        'current_level'     => 'required|min:3',
        'entry_mode'        => 'required'
        ];
    }
}
