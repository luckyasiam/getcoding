<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;
use Auth;

class SearchRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ((Auth::user()->admin == 1) && (Auth::user()->active == 1)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'search_key'       => 'required|min:3',
            'search_value'     => 'required|min:3'
        ];
    }
}
