<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

use Auth;

class InformationRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ((Auth::user())) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'        => 'required|min:3',
            'middle_name'       => 'required|min:3',
            'last_name'         => 'required|min:3',
            'date_of_birth'     => 'required|date',
            'sex'               => 'required|min:3',
            'marital_status'    => 'required|min:3',
            'state'             => 'required|min:3',
            'local_govt'        => 'required|min:3',
            'email'             => 'required|min:3',
            'phone_number'      => 'required|min:7',
            'mobile_number'     => 'required|min:7',
            'permanent_addr'    => 'required|min:3',
            'residential_addr'  => 'required|min:3',
            'next_of_kin'       => 'required|min:3',
            'next_of_kin_num'   => 'required|min:7',
            'next_of_kin_rel'   => 'required|min:3'
        ];
    }
}
