<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//  $menus = ['job' => "Jobs", 'schola' => 'Scholaships'];
//     return view('page', compact('menus'));
// });

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

//////////---- Page Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::get('users', 'UserController@index');
    Route::get('users/application', 'UserController@index');
    //Route::get('user_passport/{file_name}', 'UserPassportController@getUserImage');
});

//////////---- Admin/admins/find_user Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::post('admin/admins/find_user', 'AdminsController@showByEmail');
});

//////////---- Admin/add_admin Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/manage_users', 'AdminUserController');
});

//////////---- Admin/add_admin Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::get('admin/admins/find_user', 'AdminsController@create');
});

//////////---- Admin/admins/find_user Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::get('admin/admins/search', 'AdminsController@createUser');
});


//////////---- Admin/users Route Begin ---------//////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/users/act-users', 'ActiveUserController');
});

//////////---- Admin/ Route Begin ---------/////////////////


//////////---- Admin/email Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/email', 'EmailController');
});

//////////---- Admin/email Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/subscribers', 'SubscriberController');
});

//////////---- Admin/articles Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/articles', 'ArticleController');
});

//////////---- Admin/users/find_users Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::get('admin/users/search', 'ManageUserController@createUser');
});

//////////---- Admin/users/find_users Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::post('admin/users/search', 'ManageUserController@findByResource');
});

//////////---- Admin/user Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/users', 'ManageUserController');
});

//////////---- Admin/admins Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/admins', 'AdminsController');
});


//////////---- Admin/user{data} Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/personal_info', 'InformationController');
});

Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/ssce_result', 'ResultController');
});

Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/undergraduate', 'UndergraduateController');
});

Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/passport', 'UserPassportController');
});

Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/uploaded_doc', 'UserDocumentController');
});

Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin/{user}/bank_details', 'BankController');
});


//////////---- Users Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('users/personal_info', 'InformationController');
});

Route::group(['middleware' => ['web']], function () {
    Route::resource('users/ssce_result', 'ResultController');
});

Route::group(['middleware' => ['web']], function () {
    Route::resource('users/undergraduate', 'UndergraduateController');
});

Route::group(['middleware' => ['web']], function () {
    Route::resource('users/passport', 'UserPassportController');
});

Route::group(['middleware' => ['web']], function () {
    Route::resource('users/uploaded_doc', 'UserDocumentController');
});

Route::group(['middleware' => ['web']], function () {
    Route::resource('users/bank_details', 'BankController');
});


//////------- Authentication-------///////////
Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/', 'PageController@index');
});

//////////------Subscribe Route Begin
Route::group(['middleware' => ['web']], function () {
    Route::resource('subscribe', 'SubscribeController');
});

//////////---- Job Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/jobs', 'JobController');
});

//////////---- ItPlacement Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/it-placement', 'ItPlacementController');
});

//////////---- Bursary Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/bursary', 'BursaryController');
});

//////////---- Scholarship Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/scholarships', 'ScholarshipController');
});

//////////---- /Page Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/page', 'PageController');
});

//////////---- /about-us Route Begin ---------//////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('/about-us', 'AboutUsController');
});

//////////---- Admin Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::resource('admin', 'AdminController');
});

//////////---- Admin Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('user/database', 'DatabaseController');
});

//////////---- Admin/admins/find_user Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::post('users/submit/search', 'SubmissionController@searchUser');
});

//////////---- Admin/admins/find_user Route Begin ---------/////////////////
Route::group(['middleware' => ['web', 'admin']], function () {
    Route::get('users/submit/search', 'SubmissionController@searchUser');
});

//////////---- Admin Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::resource('users/submit', 'SubmissionController');
 });


//Route::get('/userimage/{filename}', ['uses' => 'UserPassportController@getUserImage', 'as' => 'account.image']);


////////---- user_image Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::get('user_document/{filename}', 
        [
            'uses'  => 'UserDocumentController@getUserDocument', 
            'as'    => 'account.document'
        ]);
});


////////---- user_image Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::get('userimage/{filename}', 
        [
            'uses'  => 'UserPassportController@getUserImage', 
            'as'    => 'account.image'
        ]);
});

////////---- user_image Route Begin ---------/////////////////
Route::group(['middleware' => ['web']], function () {
    Route::get('article-image/{id}', 
        [
            'uses'  => 'ArticleController@getArticleImage', 
            'as'    => 'article.image'
        ]);
});

/////-- news entertainment and the rest undefined tag Route Begin --//
Route::group(['middleware' => ['web']], function () {
    Route::get('/{tag}/{id}', 'PageController@show');
 });

/////-- news entertainment and the rest undefined tag Route Begin --//
Route::group(['middleware' => ['web']], function () {
    Route::get('/{tag}', 'PageController@show');
 });

/////-- news entertainment and the rest undefined tag Route Begin --//
Route::group(['middleware' => ['web']], function () {
    Route::get('/{tag}*', 'PageController@show');
 });


