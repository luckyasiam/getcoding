<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPassport extends Model
{
            /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [
		'user_id',
		'file_name',
		'mime',
		'original_file_name'
	];

    public function user_passport()
    {
        return $this->blongTo('App\User');
    }
}
