<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name', 'last_name', 'email', 'password', 'active', 'admin'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function article()
    {
        return $this->hasMany('App\Article');
    }

    public function information()
    {
        return $this->hasMany('App\Information');
    }

    public function result()
    {
        return $this->hasMany('App\Result');
    }

    public function bank()
    {
        return $this->hasMany('App\Bank');
    }

    public function undergraduate()
    {
        return $this->hasMany('App\Undergraduate');
    }

    public function user_passport()
    {
        return $this->hasMany('App\UserPassport');
    }

    public function user_document()
    {
        return $this->hasMany('App\UserDocument');
    }

    public function submission()
    {
        return $this->hasMany('App\Submission');
    }

    public function about_us()
    {
        return $this->hasMany('App\AboutUs');
    }
}
