<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [
        'user_id',
    	'title',
    	'image',
    	'body'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
