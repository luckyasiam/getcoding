<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Undergraduate extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [
		'user_id',
		'institution_name',
		'institution_type',
		'matric_number',
		'jamb_reg_number',
		'jamb_score',
		'faculty',
		'department',
		'course',
		'duration',
		'entry_year',
		'current_level',
		'entry_mode',
		'active'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
