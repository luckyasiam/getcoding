<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDocument extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [
        'user_id',
        'file_name',
        'mime',
        'original_file_name',
        'file_category'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
