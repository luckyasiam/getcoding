<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Information extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [

	 	'user_id',
        'first_name',
        'middle_name',
        'last_name',
        'date_of_birth',
        'sex',
        'marital_status',
        'state',
        'local_govt',
        'email',
        'phone_number',
        'mobile_number',
        'permanent_addr',
        'residential_addr',
        'next_of_kin',
        'next_of_kin_num',
        'next_of_kin_rel',
        'active'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
