<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Result extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [

    	'user_id',
    	'school_name',
    	'school_type',
    	'admission_year',
    	'graduation_year',
    	'english',
    	'mathematics',
    	'subject3',
    	'subject3_grade',
    	'subject4',
    	'subject4_grade',
    	'subject5',
    	'subject5_grade',
    	'active'

    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
