<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutUs extends Model
{
	/**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [

    	'user_id',
        'title',
        'tag',
        'body',
        'image',
        'image_name',
        'mime',
        'active',
        'status',
        'reads',
        'published_at'
    ];

    public function scopePublished($query)
    {
    	$query->where('published_at', '<=', Carbon::now());
    }
    public function scopeUnpublished($query)
    {
    	$query->where('published_at', '>', Carbon::now());
    }

    // public function setPublishedAtAttribute($date)
    // {
    // 	$this->attributes['published_at'] = Carbon::createFromFormat('Y-m-d', $date);
    // }

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
