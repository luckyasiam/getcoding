<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
    /**
	 * The attributes that are mass assignable.
	 * @var arry
	 */
    protected $fillable = [
    	'user_id',
        'bank',
        'account_name',
       	'account_number',
       	'sort_code',
        'bvn',
        'active'
    ];

    public function user()
    {
        return $this->blongTo('App\User');
    }
}
