<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUndergraduatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('undergraduates', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->string('institution_name');
            $table->string('institution_type');
            $table->string('matric_number');
            $table->string('jamb_reg_number');
            $table->integer('jamb_score')->unsigned();
            $table->string('faculty');
            $table->string('department');
            $table->string('course');
            $table->integer('duration')->unsigned();
            $table->integer('entry_year')->unsigned();
            $table->integer('current_level')->unsigned();
            $table->string('entry_mode');
            $table->boolean('active');            
            $table->boolean('status');
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('undergraduates');
    }
}
